package it.euris.academi.esame2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Esame2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Esame2023Application.class, args);
	}

}
