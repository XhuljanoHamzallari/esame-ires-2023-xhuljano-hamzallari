package it.euris.academi.esame2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Esame2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
